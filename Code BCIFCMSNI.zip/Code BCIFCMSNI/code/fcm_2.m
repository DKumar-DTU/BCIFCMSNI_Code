function [center, center11, center22, U, B, obj_fcn] = fcm_2(data,center_init,param,length1, width1)

alpha = param.alpha; %MFCM bias field Data set clustering using fuzzy c-means clustering.controls the contribution of neighborhood pixel values
% when estimating bias field. A higher alpha is preferred for a more noisy
% input image
sigma = param.sigma;%25 bias field smoothing;
expo = param.m; %fuzzifier factor
beta = param.beta;
NF = param.NF;
epsilon = param.epsilon;% epsilon is the stopping criterion as defined in Eq 19 of the paper
max_iter = param.maxit;% maxit is the maximum number of iterations performed prior to termination.
win = param.win; % Must be odd % The current function only supports win=3
obj_fcn = zeros(max_iter, 1);	% Array for objective function
%center0 = rand(cluster_n, in_n);
%sigma = var(data);
cluster_n = size(center_init,1);
% Main lo
pp_old=0;
B_init = randn(size(data))*0.0001;%.*1e-2;

%B_init = (B_init - minB)/(maxB - minB);

U_init = initfcm_2(cluster_n, size(data,1));

if NF == 1
    center_init11=((1-center_init)./(1+beta.*(center_init)));
    center_init22 = 1 - center_init - center_init11;
elseif NF ==2
    center_init11= (1-center_init.^beta).^(1/beta);%((1-defDB)./(1+beta.*(defDB)));
    center_init22 = 1 - center_init - center_init11;
elseif NF == 3
    %defDBdata11 = exp(1./log(defDB));
    eps = 0.0001;
    center_init = center_init.*(1-eps);
    center_init11 = exp((log(beta)^2)./log(center_init));%((1-defDB)./(1+beta.*(defDB)));
    center_init22 = 1 - center_init - center_init11;
end

display = 1;
%B=ones(size(data)).*1e-4; %Number of pixels
for i = 1:max_iter,
	[U, B, center, center11, center22, obj_fcn(i)] = stepfcm_2(data, center_init, center_init11, center_init22, B_init, U_init, cluster_n, expo, sigma, win, alpha, beta, length1, width1,NF);
    difC=sqrt((center_init - center).*(center_init - center));
    Cdif=sum(sum(difC));
    if display, 
		fprintf('Iteration count = %d, diff = %f\n', i, Cdif);
	end
    if (abs(pp_old-Cdif)<=epsilon), break; end,
    pp_old=Cdif;
    center_init = center;
    center_init11 = center11;
    center_init22 = center22;
    B_init = B;
    U_init = U;
    DataB(i,:) = B;
    DataU(i,:,:) = U;
    DataCenter(i,:) = center;
    DataCenter11(i,:) = center11;
    DataCenter22(i,:) = center22;
end

iter_n = i;	% Actual number of iterations 
obj_fcn(iter_n+1:max_iter) = [];
