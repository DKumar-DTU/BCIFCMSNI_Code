%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%% *This code is for validation purpose only*%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Bias-Corrected Intuitionistic Fuzzy C-Means With Spatial Neighborhood Information Approach for Human Brain MRI Image Segmentation
%% Published in IEEE Transaction on Fuzzy Systems
% The code was written by Dhirendra Kumar in 2019.
% If you have any problems, please contact me. 
% Email address: dhirendrakumar@dtu.ac.in

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
clc 
close all 
clear variables
%%%%%%%%%%%%%%%%%%----Load Synthetic Image data----%%%%%%%%%%%%%%%%%%%%%%%%
load('/data/Cir_ImgINU.mat');
load('/data/CirOrigImg.mat');

GT1 = double(im==50);
GT2 = double(im==200);
GT_img = GT1 + 2*GT2;
gcf1 = figure;
imshow(GT_img,[]);title('Ground Truth Image');
saveas(gcf1,'\results\GTImg.jpg')
a = aa;% + 30*randn(size(im));
[m, n] = size(a);
gcf2 = figure;
imshow(a,[]);title('Bias Currupted Image');
saveas(gcf2,'\results\BiasImg.jpg') 
param.alpha=0.05;  
param.sigma=20;
param.beta=1.7;
param.m=2;%opping criterion as defined in Eq 19 of the paper
param.epsilon=1e-6;%10
param.win=3; 
param.maxit = 700;
param.NF = 1;

length1=m;
width1=n;
aa=double(a);
q1=min(min(aa));
q2=max(max(aa));
aa22=(aa-q1)./(q2-q1);
data=aa22(:);
cluster_n=2;
Wsize = 3;
center_init = 200*rand(2, 1);
[center, center11, center22, U, B, obj_fcn]=fcm_2(data,center_init,param,length1, width1);
B1 = reshape(B,length1, width1);
ImOr = aa22*(q2-q1) + q1;
ImEst = (aa22 - B1)*(q2-q1) + q1;
gcf3 = figure;
imshow(B1,[]);title('Estimated Bias Field');
saveas(gcf3,'\results\BiasEst.jpg') 
%U = U1;
figure;imshow(aa22 - B1,[])
figure;imshow(aa22,[])
[~,pY_new]=max(U',[],2);
Seg=reshape(pY_new,size(im));

%%%%%%%%%%%%%%%%%%%%%%%%---Ploting Segmented image--%%%%%%%%%%%%%%%%%%%%%%%
gcf4 = figure;
imshow(Seg,[]);title('Segmented Image');
saveas(gcf4,'\results\SegRes.jpg') 

%%%%%%%%%%%%%%% Score of Average Segmentation Accuracy   %%%%%%%%%%%%%%%%%%

[ASA_Score]=Syn_ASA(double(im),Seg,GT_img);

fprintf('\nthe accuracy of the model is %f',ASA_Score)