 function [U_new, B_newF, center_new, center_new11, center_new22, obj_fcn] = stepfcm_2(data, center, center11, center22, B, U, cluster_n, expo, sigma, Wsize, alpha, beta, length1, width1,NF)

defDB = data-B;
if NF == 1
    defDBdata11=((1-defDB)./(1+beta.*(defDB)));
    defDBdata22 = 1 - defDB - defDBdata11;
elseif NF ==2
    defDBdata11= (1-defDB.^beta).^(1/beta);%((1-defDB)./(1+beta.*(defDB)));
    defDBdata22 = 1 - defDB - defDBdata11;
elseif NF == 3
    %defDBdata11 = exp(1./log(defDB));
    eps = 0.00000001;
    defDB = defDB.*(1-eps);
    defDBdata11 = exp((log(beta)^2)./log(defDB));%((1-defDB)./(1+beta.*(defDB)));
    defDBdata22 = 1 - defDB - defDBdata11;
end 

Dist = distifcm_2(center, center11, center22, defDB, defDBdata11, defDBdata22);
dist = Dist.^2;
%OU = ones(cluster_n, size(data,1));
UDC = Neigh_WDA(U, dist, cluster_n, length1, width1, Wsize);

temp = (dist + alpha*UDC).^(-1/(expo-1));
U_new = temp./(ones(cluster_n, 1)*sum(temp));

mf = U_new.^expo;

[UC, NC] = Neigh_WA(U_new, defDB, cluster_n, length1, width1, Wsize);
%dist = 2*(1-K);
center_new =((mf)*defDB + alpha*sum(mf.*NC,2))./((ones(size(data, 2), 1)*sum((mf)'))' + alpha*sum(mf.*UC,2)); % new center

[UC11, NC11] = Neigh_WA(U_new, defDBdata11, cluster_n, length1, width1, Wsize);
%dist = 2*(1-K);

center_new11 =((mf)*defDBdata11 + alpha*sum(mf.*NC11,2))./((ones(size(defDBdata11, 2), 1)*sum((mf)'))' + alpha*sum(mf.*UC11,2)); % new center

[UC22, NC22] = Neigh_WA(U_new, defDBdata22, cluster_n, length1, width1, Wsize);
%dist = 2*(1-K);

center_new22 =((mf)*defDBdata22 + alpha*sum(mf.*NC22,2))./((ones(size(defDBdata22, 2), 1)*sum((mf)'))' + alpha*sum(mf.*UC22,2)); % new center

%Nmf = Neigh_WDA(U_new, mf, cluster_n, length1, width1, Wsize);
%Beta = mf% + alpha*Nmf;

Temp1 = sum(data - ((mf'*center_new)./sum(mf)'));
Temp2 = sum((1./sum(mf)'));
lambdadiv2 = Temp1/Temp2;

B_new = data - ((mf'*center_new + lambdadiv2)./sum(mf)');

B_newF = imgaussian(reshape(B_new,[length1, width1]),sigma);
B_newF = B_newF(:);
obj_fcn = sum(sum((dist).*mf));  % objective function
% temp = (1-U)./U;
% temp1 = temp.^(expo-1);
% temp2 = 1 - temp1;
% temp3 = dist.*temp2;
% temp4 = temp3.^(-1/(expo-1));



   
