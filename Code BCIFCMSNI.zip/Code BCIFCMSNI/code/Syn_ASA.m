function [ASA_score] = Syn_ASA(img,Seg,GT)

ncluster=numel(unique(GT));
int_val=unique(GT);
for i=1:ncluster
GT_R(i)=mean(nonzeros(img.*(GT==int_val(i))));
Seg_R(i)=mean(nonzeros(img.*(Seg==i)));
end
[~,GT_ind]=sort(GT_R,'descend');
[~,Seg_ind]=sort(Seg_R,'descend');

%% Performance measure ASA
int_val=unique(GT);
S_sum=[];

for i=1:ncluster
    A=(GT==int_val(i));
    
    [~,index]=max([dice(A,(Seg==1)),dice(A,(Seg==2))]);
    B=(Seg==index);
    Seg_sum(i)=numel(nonzeros(bitand(A,B)));
    GT_sum(i)=numel(nonzeros(A));
end
ASA_score=sum(Seg_sum(1:ncluster))/sum(GT_sum(1:ncluster));
end
