function [UC, NC]= Neigh_WA(U, data, cluster_n, length1, width1, Wsize)
% % adding distance term in the " a robust fuzzy local information c-means clustering algorithim"
n1 = Wsize;
m=length1;
n=width1;
HHtm = zeros(cluster_n,m*n);
HHtm1 = zeros(cluster_n,m*n);
               %size(HH)
             h = ones(n1,n1)/(n1*n1-1);%filter
             h((n1+1)/2,(n1+1)/2) = 0;
               x = reshape(data, m, n);
%               x = padarray(x,[n1 n1]);
%U = U;
    for l=1:cluster_n
            U11=reshape(U(l,:), m, n);
            %U11=padarray(U11,[n1 n1]);
%             sim1=reshape(sim(l,:),m,n);
%             sim1=padarray(sim1,[1 1]);
            %HHtemp=zeros(m,n);
            %HHtemp1=zeros(m,n);
                  %PI1=reshape(pi_1(1,:),m,n);
             %sim1;%zeros(m,n);
            % HH1=padarray(HHtemp,[n1 n1]);%sim1;%zeros(m,n);
            % HH2=padarray(HHtemp1,[n1 n1]);
%              mm=m+2*n1;   %m+2 m + 2*n1for wsize 3
%              nn=n+2*n1;
             U111 = U11.*x;
             HHtemp = imfilter(U111,h);
             HHtemp1 = imfilter(U11,h);
             HHtemp = HHtemp./HHtemp1;
             HHtemp1 = HHtemp1./HHtemp1;
%             for i=n1+1:mm-n1                   %window size 3x3
%                   for j=n1+1:nn-n1
%                       % window search and center pixel act as (i,j)
%                       gg1 = 0;  %window size 3x3
%                       gg2 = 0;
%                       gg3 = 0;
%                      for ii=i-n1:i+n1
%                           for jj=j-n1:j+n1
%                               if (ii~=i && jj~=j)
%                                dist_s=0;%sqrt((ii-i)^2+(jj-j)^2);
% %                               dist=dist+dist_s;%(1-(U11(ii,jj)))^(expo)*(dist_s);
%                                gg1 = gg1 + ((1/(dist_s + 1))*((U11(ii,jj))))*x(ii,jj);%(data(ii,jj)-data(i,j));
% %                               dist
%                                gg2 = gg2 + ((1/(dist_s + 1))*((U11(ii,jj)))); 
%                                
%                                gg3 = gg3 + U11(ii,jj);
% %                              vec1(k)=data(ii,jj);
% %                              k=k+1;
%                               end
%                           end
%                      end
%                       
%                 HH1(i, j) = gg1./gg3;%((sim11/9)+gg1);%(dist+1); %/(var(vec1));/(var(vec1));
%                 HH2(i, j) = gg2./gg3;
%                  end
%             end
            %HHtemp = HH1(n1+1:mm-n1,n1+1:nn-n1);
            %HHtemp1 = HH2(n1+1:mm-n1,n1+1:nn-n1);
          HHtm(l,:) = HHtemp(:);
          HHtm1(l,:) = HHtemp1(:);
    end
   NC = HHtm;   
   UC = HHtm1;
end
%               HH1=HH1(2:mm-1,2:nn-1);
%               HH2=HH2(2:mm-1,2:nn-1);
%               HH3=HH3(2:mm-1,2:nn-1);
%               HH4=HH4(2:mm-1,2:nn-1);
%       % size(HH1)
%      HH=[HH1(:)';HH2(:)';HH3(:)';HH4(:)'];
%     % size(HH)
   
